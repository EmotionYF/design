<template>
    <div>
        <div class="myheader">
                <img  v-if="icon=='back'" @click="goLastPage" src="../../img/common/backWhite.png" class="myheader-icon-bg" >
            <span class="myheader-title">{{headerTitle}}</span>
        </div>
        <div class="myheader-bg"></div>
    </div>
</template>
<script>
    export default{
        components: {},
        props: {
            headerTitle: {  //头部标题
                required: true
            },
            targetPath: {//目标路径（返回的路径）
                default:-1,
            },
            icon:{
                default:'back'
            },
            isreplace:{
                default:true
            }
        },
        created(){
        },
        mounted(){
        },
        data(){
            return {
            }
        },
        methods: {
            goLastPage(){
                if(this.targetPath==-1){
                    this.$router.go(-1);
                    return;
                }
                else{
                    if(this.isreplace){
                        this.$router.replace(this.targetPath);
                    }
                    else{
                        this.$router.push(this.targetPath);
                    }
                }
            }
        },
    }
</script>
<style lang="scss" scoped type="text/scss">
    .myheader{
        font-size: 16px;
        color: #414141;
        height: .44rem;
        line-height: .44rem;
        position: fixed;
        width: 100%;
        z-index: 1;
        display: flex;
        align-items: center;
        background:linear-gradient(270deg,rgba(216,24,35,1) 0%,rgba(211,42,48,1) 100%);
    }
    .myheader-bg{
        width: 100%;
        height: .44rem;
    }
    .myheader-icon-bg{
        width: .23rem;
        height: .23rem;
        position: absolute;
        z-index: 1;
        left: .12rem;
    }
    .myheader-title{
        font-size:.16rem;
        position: absolute;
        display: block;
        text-align: center;
        width: 100%;
        font-family:PingFangSC-Regular,PingFang SC;
        font-weight:400;
        color:rgba(255,255,255,1);
    }
</style>
