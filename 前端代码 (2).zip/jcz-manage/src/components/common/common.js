                  /**
 * Created by 82592 on 2018/8/30.
 */
var aCity={11:"北京",12:"天津",13:"河北",14:"山西",15:"内蒙古",21:"辽宁",22:"吉林",23:"黑龙江",31:"上海",32:"江苏",33:"浙江",34:"安徽",35:"福建",36:"江西",37:"山东",41:"河南",42:"湖北",43:"湖南",44:"广东",45:"广西",46:"海南",50:"重庆",51:"四川",52:"贵州",53:"云南",54:"西藏",61:"陕西",62:"甘肃",63:"青海",64:"宁夏",65:"新疆",71:"台湾",81:"香港",82:"澳门",91:"国外"};
export function checkSpace(str) {
    var reg = /\s/g;
    if (reg.test(str)) {
        return true;
    };
    return false;
}
export function dateForment(date,format='yyyy-MM-dd HH:mm:ss'){
    let t = new Date(date);
    console.log(t.getFullYear())
    let tf = function(i){return (i < 10 ? '0' : '') + i};
    return format.replace(/yyyy|MM|dd|HH|mm|ss/g, function(a){
        switch(a){
            case 'yyyy':
                return tf(t.getFullYear());
                break;
            case 'MM':
                return tf(t.getMonth() + 1);
                break;
            case 'mm':
                return tf(t.getMinutes());
                break;
            case 'dd':
                return tf(t.getDate());
                break;
            case 'HH':
                return tf(t.getHours());
                break;
            case 'ss':
                return tf(t.getSeconds());
                break;
        }
    });

}
export function checkIdCard(value){
    var iSum=0 ;
    //身份证位数校验
    if(!/^\d{17}(\d|x)$/i.test(value))
        return false;
    value=value.replace(/x$/i,"a");
    //身份证省份校验
    if(aCity[parseInt(value.substr(0,2))]==null)
        return true;
    //身份证生日校验
    var sBirthday=value.substr(6,4)+"-"+Number(value.substr(10,2))+"-"+Number(value.substr(12,2));
    var d=new Date(sBirthday.replace(/-/g,"/")) ;
    if(sBirthday!=(d.getFullYear()+"-"+ (d.getMonth()+1) + "-" + d.getDate()))
        return false;
    //身份证校验码
    for(var i = 17;i>=0;i --) iSum += (Math.pow(2,i) % 11) * parseInt(value.charAt(17 - i),11) ;
    if(iSum%11!=1)
        return false;
    return true;
}
export function setCookie(name,value,time=2*60*60*1000) {

    var exp = new Date();
    exp.setTime(exp.getTime() + time);
    document.cookie = name + "="+ escape (value) + ";expires=" + exp.toGMTString();
}
//读取cookies
export function getCookie(name) {
    var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");

    if(arr=document.cookie.match(reg))

        return unescape(arr[2]);
    else
        return null;
}
//删除cookies
export function delCookie(name) {
    var exp = new Date();
    exp.setTime(exp.getTime() - 1);
    var cval=getCookie(name);
    if(cval!=null)
        document.cookie= name + "="+cval+";expires="+exp.toGMTString();
}

export function queryURLParameter(str=location.href) {
    var reg = /([^?&=#]+)=([^?&=#]+)/g,
        obj = {};
    str.replace(reg, function() {
        obj[arguments[1]] = arguments[2];
    });
    return obj;
}


 export function setLocalStg(key,value){
    console.log(1)
    localStorage.setItem(key,value);
 }
 export function getLocalStg(key){
    console.log(1)
    return localStorage.getItem(key)
}
export function removeLocalStg(key){
    localStorage.removeItem(key)
}



export function checkTwoDecimalPoint(rule, value, callback){
    value=value+"";
    console.log(rule);
    if(value==""){
        callback();
    }
    let arr=value.split(".");
    if(arr.length==2&&arr[1].length>2){
        callback(new Error('小数点后只能两位小数'));
    }
    callback();
}
export function checkRate(rule, value, callback){
    if(value==""){
        callback();
    }
    console.log("value:",value,typeof value)
    value=value+"";
    let arr=value.split(".");
    if(arr.length==2&&arr[1].length>2){
        callback(new Error('小数点后只能两位小数'));
    }
    if(parseFloat(value)>=10000){
        callback(new Error('您输入的分佣过大，请重新输入'));
    }
    if(parseFloat(value)<0){
        callback(new Error('您输入的分佣太小，请重新输入'));
    }
    callback();
}

export   function checkExcel(fileDir){
          var suffix = fileDir.substr(fileDir.lastIndexOf("."));
          if("" == fileDir){
              return false;
          }
          if(".xls" != suffix && ".xlsx" != suffix ){
              return false;
          }
          return true;
      }

export function accAdd(num1, num2) {//加法
            num1 = Number(num1);
            num2 = Number(num2);
            var dec1, dec2, times;
            try { dec1 = countDecimals(num1)+1; } catch (e) { dec1 = 0; }
            try { dec2 = countDecimals(num2)+1; } catch (e) { dec2 = 0; }
            times = Math.pow(10, Math.max(dec1, dec2));
            // var result = (num1 * times + num2 * times) / times;
            var result = (accMul(num1, times) + accMul(num2, times)) / times;
            return getCorrectResult("add", num1, num2, result);
            // return result;
        };

export  function accSub(num1, num2) {//减法
            num1 = Number(num1);
            num2 = Number(num2);
            var dec1, dec2, times;
            try { dec1 = countDecimals(num1)+1; } catch (e) { dec1 = 0; }
            try { dec2 = countDecimals(num2)+1; } catch (e) { dec2 = 0; }
            times = Math.pow(10, Math.max(dec1, dec2));
            // var result = Number(((num1 * times - num2 * times) / times);
            var result = Number((accMul(num1, times) - accMul(num2, times)) / times);
            return getCorrectResult("sub", num1, num2, result);
            // return result;
        };
        
export    function accDiv(num1, num2) {//除法
            num1 = Number(num1);
            num2 = Number(num2);
            var t1 = 0, t2 = 0, dec1, dec2;
            try { t1 = countDecimals(num1); } catch (e) { }
            try { t2 = countDecimals(num2); } catch (e) { }
            dec1 = convertToInt(num1);
            dec2 = convertToInt(num2);
            var result = accMul((dec1 / dec2), Math.pow(10, t2 - t1));
            return getCorrectResult("div", num1, num2, result);
            // return result;
        };
        
export  function accMul(num1, num2) {//乘法
            num1 = Number(num1);
            num2 = Number(num2);
            var times = 0, s1 = num1.toString(), s2 = num2.toString();
            try { times += countDecimals(s1); } catch (e) { }
            try { times += countDecimals(s2); } catch (e) { }
            var result = convertToInt(s1) * convertToInt(s2) / Math.pow(10, times);
            return getCorrectResult("mul", num1, num2, result);
            // return result;
        };
        
        var countDecimals = function(num) {
            var len = 0;
            try {
                num = Number(num);
                var str = num.toString().toUpperCase();
                if (str.split('E').length === 2) { // scientific notation
                    var isDecimal = false;
                    if (str.split('.').length === 2) {
                        str = str.split('.')[1];
                        if (parseInt(str.split('E')[0]) !== 0) {
                            isDecimal = true;
                        }
                    }
                    let x = str.split('E');
                    if (isDecimal) {
                        len = x[0].length;
                    }
                    len -= parseInt(x[1]);
                } else if (str.split('.').length === 2) { // decimal
                    if (parseInt(str.split('.')[1]) !== 0) {
                        len = str.split('.')[1].length;
                    }
                }
            } catch(e) {
                throw e;
            } finally {
                if (isNaN(len) || len < 0) {
                    len = 0;
                }
                return len;
            }
        };
        
        var convertToInt = function(num) {
            num = Number(num);
            var newNum = num;
            var times = countDecimals(num);
            var temp_num = num.toString().toUpperCase();
            if (temp_num.split('E').length === 2) {
                newNum = Math.round(num * Math.pow(10, times));
            } else {
                newNum = Number(temp_num.replace(".", ""));
            }
            return newNum;
        };
        
        function getCorrectResult(type, num1, num2, result) {
            var temp_result = 0;
            switch (type) {
                case "add":
                    temp_result = num1 + num2;
                    break;
                case "sub":
                    temp_result = num1 - num2;
                    break;
                case "div":
                    temp_result = num1 / num2;
                    break;
                case "mul":
                    temp_result = num1 * num2;
                    break;
            }
            if (Math.abs(result - temp_result) > 1) {
                return temp_result;
            }
            return result;
        };



