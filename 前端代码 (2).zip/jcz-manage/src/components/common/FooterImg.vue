<template>
    <div class="footerImgWarp" v-if="hidshow">
        <div class="fillDiv"></div>
        <img src="../../img/common/footerImg.png" class="footerImg">
    </div>

</template>

<script>
    export default {
        name: "FooterImg",
        components: {},
        props:{

        },
        data() {
            return {
                docmHeight: document.documentElement.clientHeight,  //默认屏幕高度
                showHeight: document.documentElement.clientHeight,   //实时屏幕高度
                hidshow:true  //显示或者隐藏footer
            }
        },
        watch: {
            showHeight:function() {
                if(this.docmHeight > this.showHeight){
                    this.hidshow=false
                }else{
                    this.hidshow=true
                }
            }
        },

        created() {
        },
        mounted() {
            this.$nextTick(()=>{
                this.docmHeight=document.documentElement.clientHeight;
                window.addEventListener("resize",this.resizeHeight,false)
            })
        },
        destroyed(){

                window.removeEventListener("resize",this.resizeHeight)

        },
        methods: {
            resizeHeight(){
                this.showHeight = document.body.clientHeight;

            }
        },
    }
</script>

<style lang="scss" scoped type="text/scss">
    .footerImgWarp {
        position: fixed;
        
        bottom: 0;
        font-size: 0;


        .fillDiv{
            width: 100%;
            height: .96rem;
        }
        .footerImg {
            width: 100%;
            height: .96rem;
        }
    }
</style>
