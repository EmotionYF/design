<template>
    <div class="footerBtn">
        <div class="btnSolid"></div>
        <div class="btnWarp">
            <div class="leftBtn" v-if="isActive===1"><img src="../../img/common/hotProduct.png">热销产品</div>
            <div class="unLeftBtn" @click="goPage(1)" v-else><img src="../../img/common/unHotProduct.png">热销产品</div>
            <div class="center" ></div>
            <div class="rightBtn" v-if="isActive===2"><img src="../../img/common/user.png">个人中心</div>
            <div class="unRightBtn" @click="goPage(2)" v-else><img src="../../img/common/unUser.png">个人中心</div>
        </div>
    </div>

</template>

<script>
    export default {
        name: "FooterBtn",
        components: {},
        created() {
        },
        mounted() {
        },
        props:{
            isActive:{
                default:1,
                type:Number
            }
        },
        watch: {},
        data() {
            return {}
        },
        methods: {
            goPage(page){
                if(page==1){
                    this.$router.replace("/productList")
                }
                else if(page==2){
                    this.$router.replace("/userCenter")
                }
            }
        },
    }
</script>

<style lang="scss" scoped type="text/scss">
    .footerBtn {
        .btnSolid{
            width: 100%;
            height: .5rem;
        }
        .btnWarp{
            position: fixed;
            
            bottom: 0;
            display: flex;
            align-items: center;

            width: 100%;
            height: .5rem;
            background:rgba(249,249,249,1);
            .leftBtn{
                flex: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                height:0.22rem;
                font-size:0.16rem;
                font-family:PingFang-SC-Medium,PingFang-SC;
                font-weight:500;
                color:rgba(216,24,35,1);
            img{
                margin-right: .12rem;
                width: .26rem;
                height: .26rem;

            }
            }
            .unLeftBtn{
                flex: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                height:0.22rem;
                font-size:0.16rem;
                font-family:PingFang-SC-Medium,PingFang-SC;
                font-weight:500;
                color:#999999;
            img{
                margin-right: .12rem;
                width: .26rem;
                height: .26rem;

            }
            }
            .center{
                width:1px;
                height:0.3rem;
                background:rgba(216,216,216,1);
            }
            .rightBtn{
                flex: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                height:0.22rem;
                font-size:0.16rem;
                font-family:PingFang-SC-Medium,PingFang-SC;
                font-weight:500;
                color:rgba(216,24,35,1);
                img{
                    margin-right: .12rem;
                    width: .26rem;
                    height: .26rem;
                }
            }
            .unRightBtn{
                flex: 1;
                display: flex;
                align-items: center;
                justify-content: center;
                height:0.22rem;
                font-size:0.16rem;
                font-family:PingFang-SC-Medium,PingFang-SC;
                font-weight:500;
                color:#999999;
                img{
                    margin-right: .12rem;
                    width: .26rem;
                    height: .26rem;
                }
            }
        }
    }
</style>
