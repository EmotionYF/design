<template>
    <div>
        <div class="loading" v-if="showLoading" @touchmove.prevent>
            <div class="loading-img">
                    <img src="../../img/loading/loading.gif">
            </div>
        </div>
    </div>
</template>
<script>
    export default{
        props: {
            showLoading:{
                default:false
            }
        },
        components: {},
        watch:{
            showLoading(curVal,oldVal){
            }
        },
        created(){
        },
        mounted(){
        },
        data(){
            return {

            }
        },
        methods: {
        },
    }
</script>
<style scoped lang="scss" type="text/scss">
    .loading-text{
        color: white;
        font-size: 0.15rem
    }
    .loading{
        position: fixed;
        top: 0;
        
        width: 100%;
        height: 100%;
        background-color:rgba(255,255,255,0.5);
        z-index: 1900;
    }
.loading-img{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%,-50%);
        img{
            width: .6rem;
            height: .6rem;
        }
}
</style>
