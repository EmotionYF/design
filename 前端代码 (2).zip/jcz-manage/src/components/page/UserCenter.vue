<template>
    <div class="userCenter">
        <div class="userInfoWarp">
            <div class="headerWarp" @click="goPage('/userInfo')">
                <img :src="userInfo.avatar" class="headerImg">
                <div class="headerUserInfo">
                    <div class="userNameAndMsg">
                        <div class="userName">Hi,{{userInfo.name}}欢迎回来</div>
                        <div class="userMsg" @click.stop="goPage('/messageCenter')">
                            <img src="../../img/user/msgIcon.png"/>
                            <span class="msgDot" v-if="userInfo.unReadNum">{{userInfo.unReadNum}}</span>
                        </div>

                    </div>
                    <div class="userNum">工号：{{userInfo.jobNumber}}</div>
                </div>
            </div>
            <div class="policyNumWarp">
                <div class="title">
                    保单统计
                </div>
                <div class="contentWarp">
                    <div>
                        <div class="topContent">累计投保（元）</div>
                        <div class="bottomContent">{{userInfo.sumPrem}}元</div>
                    </div>
                    <div>
                        <div class="topContent">累计件数（件）</div>
                        <div class="bottomContent">{{userInfo.resultCount}}件</div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mobileTips" @click="bindMoblie()" :style="userInfo.isBandMobile!=1?'height:.25rem':'height:0'">
            <span><img src="../../img/user/tips.png" width="18"/>尚未绑定手机号</span>
            <span><img @click.stop="userInfo.isBandMobile = 1" src="../../img/common/false.png" width="18"/></span>
        </div>
        <div class="policyWarp">
            <div class="policyBtnList">
                <div class="title">
                    保单相关
                </div>
                <div class="treasureItem">
                    <div class="item" @click="goPage('/policyList',{type:0})">
                        <div class="itemImg">
                            <img src="../../img/user/audit.png">
                        </div>
                        <div class="itemText">全部</div>
                    </div>
                    <div class="item" @click="goPage('/policyList',{type:1})">
                        <div class="itemImg">
                            <img src="../../img/user/pay.png">
                            <span v-if="userInfo.unPayNum!=0">{{userInfo.unPayNum}}</span>
                        </div>
                        <div class="itemText">待支付</div>
                    </div>
                    <div class="item" @click="goPage('/policyList',{type:2})">
                        <div class="itemImg">
                            <img src="../../img/user/feedback.png">
                            <span v-if="userInfo.unReceiptNum!=0">{{userInfo.unReceiptNum}}</span>
                        </div>
                        <div class="itemText">待回执</div>
                    </div>
                    <div class="item" @click="goPage('/policyList',{type:3})">
                        <div class="itemImg">
                            <img src="../../img/user/other.png">
                            <span v-if="userInfo.unOtherNum!=0">{{userInfo.unOtherNum}}</span>
                        </div>
                        <div class="itemText">其他</div>
                    </div>

                </div>
            </div>
            <div class="actionList">
                <div class="actionItem" @click="goPage('/userInfo')">
                    <div class="actionLeft">
                        <img src="../../img/user/userCenter.png">
                        <span>个人信息</span>
                    </div>
                    <img class="openImg" src="../../img/common/open.png">
                </div>
                <!--<div class="actionItem" @click="goPage('/policyManage')">-->
                    <!--<div class="actionLeft">-->
                        <!--<img src="../../img/user/policyManage.png">-->
                        <!--<span>保单管理</span>-->
                    <!--</div>-->
                    <!--<img class="openImg" src="../../img/common/open.png">-->
                <!--</div>-->
                <div class="actionItem" @click="showCustomerService">
                    <div class="actionLeft">
                        <img src="../../img/user/serviceIcon.png">
                        <span>一键客服</span>
                    </div>
                    <img class="openImg" src="../../img/common/open.png">
                </div>

            </div>
        </div>
        <div class="bgColor"></div>
        <FooterBtn :isActive=2></FooterBtn>
    </div>
</template>

<script>
  import { dateFormat,getSession,setSession,delSession,setLocalStg} from '../../utils/common';
    import FooterBtn from "../common/FooterBtn";
    export default {
        name: "UserCenter",
        components: {FooterBtn},
        created() {
        },
        mounted() {
          ///setLocalStg("JDT-WX-TOKEN","abc");
          this.getPersonIndex()
        },
        watch: {},
        data() {
            return {
                setp: 1,
              userInfo:""
            }
        },
        beforeRouteLeave(to, from, next) {
            if (this.setp > 1) {
                this.setp--;
                next(false)
            } else {
                next()
            }
        },

        methods: {
          //获取基本信息
          getPersonIndex(){
            this.$http({
              method: "POST",
              url: this.$api.personIndex,
              data: {
              }
            })
              .then(res => {
                if (res.code == 200) {
                  this.userInfo = res.data
                } else {
                  this.$toast(res.message);
                }
              })
              .catch(rtn => {
                console.log(rtn);
              });
          },
          //修改手机号
          bindMoblie(){
              //alert('aaa')
              this.$router.push('UpdateMobile')
          },
          //页面跳转
            goPage(path,params){
                this.$router.push({path:path,query:params})
            },
          //显示客服联系方式
            showCustomerService(){
                this.$dialog.alert({
                    title:"客服电话",
                    message: `<a href="tel:4008667668">400-8667668</a>`,
                    confirmButtonColor:"#D81823",
                    confirmButtonText:"确定"
                }).then(() => {
                    //TODO 跳转修改密码
                });
            }
        },
    }
</script>

<style lang="scss" scoped type="text/scss">
    .userCenter {
        height: 100%;

        .userInfoWarp {
            position: relative;
            width: 100%;
            height: 1.65rem;
            background: $defaultColor;

            .headerWarp {
                padding-top: .17rem;
                display: flex;
                align-items: center;

                .headerImg {
                    width: .7rem;
                    height: .7rem;
                    border-radius: 50%;
                    margin-left: .16rem;
                    margin-right: .09rem;
                }

                .headerUserInfo {
                    flex: 1;
                    margin-right: .16rem;

                    .userNameAndMsg {
                        display: flex;
                        justify-content: space-between;
                        align-items: center;

                        .userName {
                            height: 0.16rem;
                            line-height: 0.16rem;
                            font-size: 0.16rem;
                            font-family: Microsoft YaHei;
                            font-weight: bold;
                            color: rgba(255, 255, 255, 1);

                        }

                        .userMsg {
                            position: relative;
                            width: .2rem;
                            height: .2rem;

                            img {
                                width: .2rem;
                                height: .2rem;
                            }

                            .msgDot {
                                position: absolute;
                                padding: 0 .03rem;
                                right: -.05rem;
                                top: -.03rem;
                                height: 0.1rem;
                                line-height: .1rem;
                                font-size: 0.08rem;
                                font-family: Microsoft YaHei;
                                font-weight: 300;
                                border-radius: .05rem;
                                min-width: .04rem;
                                background: #fff;
                                color: $defaultColor;


                            }
                        }
                    }

                    .userNum {
                        margin-top: .07rem;
                        height: 0.12rem;
                        line-height: .12rem;
                        font-size: 0.12rem;
                        font-family: Microsoft YaHei;
                        font-weight: 300;
                        color: rgba(255, 255, 255, 1);
                    }
                }
            }

            .policyNumWarp {
                position: absolute;
                bottom: -.47rem;
                margin: 0 auto;
                left: 50%;
                transform: translate(-50%, 0);
                overflow: hidden;
                padding-left: .25rem;
                box-sizing: border-box;
                width: 3.43rem;
                background: rgba(255, 255, 255, 1);
                border-radius: .03rem;
                box-shadow: 0.03rem 0rem 0.07rem rgba(209, 19, 16, 0.32);
                .title {
                    margin-top: .18rem;
                    height: 0.16rem;
                    line-height: 0.16rem;
                    font-size: 0.16rem;
                    font-family: Microsoft YaHei;
                    font-weight: bold;
                    color: rgba(65, 65, 65, 1);

                }

                .contentWarp {
                    display: flex;
                    justify-content: space-between;
                    margin: .14rem .71rem .18rem 0;

                    .topContent {
                        height: 0.12rem;
                        line-height: 0.12rem;
                        font-size: 0.12rem;
                        font-family: Microsoft YaHei;
                        font-weight: 300;
                        color: rgba(129, 129, 129, 1);

                    }

                    .bottomContent {
                        margin-top: .09rem;
                        height: 0.16rem;
                        line-height: 0.16rem;
                        font-size: 0.16rem;
                        font-family: Source Han Sans SC;
                        font-weight: 400;
                        color: rgba(65, 65, 65, 1);

                    }
                }

            }
        }
        .mobileTips{
            margin-top: .57rem;
            background: #F5F5F5;
            overflow: hidden;
            padding: 0 .17rem;
            display: flex;
            align-items: center;justify-content: space-between;
            span{
                display: flex;align-items: center;
                color: #FC8D00;
                font-size: .12rem;

            }
            img{
                width: .18rem;height: .18rem;
            }
        }
        .policyWarp {
            background: #fff;

            .policyBtnList {
                border-bottom: 1px solid #F9F9F9;

                .title {
                    padding-left: .17rem;
                    height: .28rem;
                    line-height: .28rem;
                    font-size: 0.12rem;
                    font-family: Microsoft YaHei;
                    font-weight: 300;
                    color: rgba(65, 65, 65, 1);
                    border-bottom: 1px solid #F9F9F9;

                }

                .treasureItem {
                    display: flex;
                    margin: .21rem .4rem .14rem;
                    justify-content: space-between;

                    .item {
                        .itemImg {
                            text-align: center;
                            position: relative;
                            width: .27rem;
                            margin: 0 auto;
                            img {
                                width: .27rem;
                                height: .27rem;
                            }
                            span{
                                position: absolute;
                                padding: 0 .03rem;
                                right: -.05rem;
                                height: 0.1rem;
                                line-height: .1rem;
                                background: #D81823;
                                font-size: 0.08rem;
                                font-family: Microsoft YaHei;
                                font-weight: 300;
                                color: white;
                                border-radius: .05rem;
                                min-width: .04rem;
                            }
                        }

                        .itemText {
                            height: 0.14rem;
                            line-height: 0.14rem;
                            font-size: 0.14rem;
                            font-family: Microsoft YaHei;
                            font-weight: 400;
                            color: rgba(65, 65, 65, 1);

                        }
                    }
                }
            }

            .actionList {
                .actionItem {
                    height: .5rem;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 0 .16rem;
                    border-bottom: 1px solid #F9F9F9;

                    .actionLeft {
                        display: flex;
                        align-items: center;

                        img {
                            width: .27rem;
                            height: .27rem;
                            margin-right: .08rem;
                        }

                        span {
                            height: 0.14rem;
                            line-height: .14rem;
                            font-size: 0.14rem;
                            font-family: Source Han Sans SC;
                            font-weight: 400;
                            color: rgba(65, 65, 65, 1);
                        }
                    }

                    .openImg {
                        width: .17rem;
                        height: .17rem;
                    }
                }
            }
        }
        .bgColor{
            position: fixed;
            top: 0;
            background: #f9f9f9;
            width: 100%;
            height: 50%;
            z-index: -1;
        }

    }
</style>
