<template>
    <div class="ChangePassword">
        <!--<div class="headerImg">-->
            <!--<img src="" width="130" height="130px"/>-->
            <!--<el-button type="text">上传头像</el-button>-->
        <!--</div>-->
        <el-form ref="officeForm" :rules="rule" :model="sendInfo" label-width="80px" label-position="right" style="width:400px ;text-align:left">
            <el-form-item label="用户名" >
                <el-input width="300" disabled type="text" v-model="userName" ></el-input>
            </el-form-item>
            <el-form-item label="手机号" >
                <el-input width="300" disabled type="text" v-model="phone" ></el-input>
            </el-form-item>
            <el-form-item label="旧密码"  prop="oldPassword" >
                <el-input width="300" type="text" v-model="sendInfo.oldPassword" show-password placeholder="请输入原密码"></el-input>
            </el-form-item>
            <el-form-item label="新密码" prop="newPassword" >
                <el-input width="300" type="text" onKeyUp="value=value.replace(/[\W]/g,'')" v-model="sendInfo.newPassword"   show-password placeholder="请输入新密码"></el-input>
            </el-form-item>
            <el-form-item label="确认密码" prop="verifyPassword">
                <el-input width="300" type="text" onKeyUp="value=value.replace(/[\W]/g,'')" v-model="sendInfo.verifyPassword"   show-password placeholder="请确认新密码"></el-input>
            </el-form-item>
        </el-form>
        <el-button type="primary" size="mini" icon="add" @click="checkInfo()">确认提交</el-button>
        <el-dialog title="提示信息" :visible.sync="changeStatus" width="30%" :close-on-click-modal="false">
            <div>确认修改密码？</div>
            <span slot="footer" class="dialog-footer">
                <el-button type="info" @click="changeStatus = false">取 消</el-button>
                <el-button type="primary" @click="changePassword()">确 定</el-button>
            </span>
        </el-dialog>
    </div>
</template>

<script>
    import {removeLocalStg} from "../common/common";
    import api from  "../../axios/api";
    export default {
        data(){
            return{
                sendInfo:{
                    oldPassword:'',
                    newPassword:'',
                    verifyPassword:'',
                },
                rule:{
                    oldPassword:[
                        {required: true, message: '请输入原密码', trigger: 'blur'},
                    ],
                    newPassword:[
                        {required: true, message: '请输入新密码', trigger: 'blur'},
                        {required: true,min:6,message: '新密码不能低于6位', trigger: 'blur'},
                    ],
                    verifyPassword:[
                        {required: true, message: '请输入确认密码', trigger: 'blur'},
                    ]
                },
                changeStatus:false,
                userName:"",
                phone:"",
            }
        },

        methods:{
            checkInfo(){
                let submitStatus = true;
                //提交表单校验
                this.$refs["officeForm"].validate((valid) => {
                    if (valid) {
                        submitStatus = true;
                    } else {
                        submitStatus = false;
                    }
                });
                //校验失败
                if (!submitStatus) {
                    this.$message.error("请检查表单必填项");
                    return;
                }

                if(this.sendInfo.newPassword!=this.sendInfo.verifyPassword){
                        this.$message.error(`两次密码不一致，请重新输入`);
                    return
                }else{
                    this.changeStatus = true
                }
            },
            changePassword(){

                this.$http({
                    method: 'post',
                    url: api.updatePassword,
                    headers:{},
                    data:this.sendInfo
                })
                    .then((response)=> {
                        if(response.code==200){
                            this.changeStatus = false;
                            removeLocalStg('JDT_MANAGE_TOKEN')
                            this.$router.replace("/login")
                            this.$message.success(`修改成功`);
                        }else{
                            this.$message.error(response.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(`网络错误`);
                    })
            },
            findAccount(){
                this.$http({
                    method: 'get',
                    url: api.findAccount,
                    headers:{},
                    data:{},
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.userName = res.data.realName
                            this.phone = res.data.phone
                        }else{
                            this.$message.error(response.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(`网络错误`);
                    })
            },
        },
        mounted(){
            this.findAccount()
        },
    }
</script>

<style>
    .ChangePassword{
        width: 100%;height: 100%;
        display: flex;
        align-items: center;justify-content: center;
        flex-direction: column;
    }
    .ChangePassword .headerImg{
        width:130px;height: 170px;
        display: flex;
        align-items: center;justify-content: space-around;
        flex-direction: column;
    }
    .headerImg img{
        width:130px;height: 130px;
        border-radius: 100%;
    }
</style>