<template>
    <div class="dashboard">
        <h2 class="titleText">直营订单统计</h2>
        <!--<div style="text-align: center;color: #cccccc">更新时间：2020-01-21  12：22</div>-->
        <div style="text-align: center;color: #cccccc">更新时间：{{newDate|timeSplit }}</div>

        <el-card style="margin:50px 0 30px;">
            <div slot="header">
                <span>总成交（总成交统计已完成订单和数据金额）</span>
            </div>
            <el-row>
                <el-col style="text-align: center" :span="12">总订单数<div style="font-size:25px;margin: 20px 0 20px 160px;font-weight: bold">{{indexInfo.allOrderCount}}</div></el-col>
                <el-col style="text-align: center" :span="12">总成交额<div style="font-size:25px;margin: 20px 0 20px 160px;font-weight: bold">￥{{indexInfo.allMoney}}</div></el-col>
            </el-row>
        </el-card>
        <el-card style="margin-bottom: 30px">
            <div slot="header" >
                <span>今日成交订单和金额</span>
            </div>
            <el-row>
                <el-col style="text-align: center" :span="6">下单数<div style="font-size:25px;font-weight: bold;margin: 30px  0 20px ">{{indexInfo.nowDayOrderCount}}</div></el-col>
                <el-col style="text-align: center" :span="6">下单总金额<div style="font-size:25px;font-weight: bold;margin: 30px  0 20px ">￥{{indexInfo.nowDayMoney}}</div></el-col>
            </el-row>
        </el-card>
    </div>
</template>

<script>
import bus from '../common/bus';
import {dateForment} from '../common/common';
import echarts from 'echarts';
export default {
    name: 'dashboard',
    components:{
        dateForment
    },
    data() {
        return {
            indexInfo:"",//首页信息
            newDate:Date.parse(new Date()),//更新时间显示当前时间
        };
    },
    mounted(){
        this.getDashboardInfo()
    },

    computed: {
    },
    filters: {
        timeSplit(v) {
            return dateForment(v,'yyyy-MM-dd');
        }
    },
    methods: {
        //时间戳换成日期
        formatDate(time,column) {
            alert(time)
            console.log(time)
            return(dateForment(time,"yyyy-MM-dd HH:mm:ss"));
        },
        getDashboardInfo(){
            this.$http({
                method: 'post',
                url: this.$api.indexInfo,
                headers:{},
                data:{
                }
            })
                .then((res)=> {
                    if(res.code==200){
                       this.indexInfo = res.data

                    }else{
                        this.$message.error(res.message);
                    }
                })
                .catch((error)=> {
                    this.$message.error(error);
                })
        },
    }
};
</script>


<style scoped>
    .dashboard{

    }
 .dashboard .titleText{
     padding: 20px;
     border-bottom: 1px solid #CCCCCC;
 }
 .dashboard .tipsItem{
    background: #FFF;
    height: 100px;
     min-width: 190px;
    border: 1px solid #e4e4e4;
    display: flex;
    align-items: center;
     padding-left: 20px;
}
 .dashboard .entranceItem{
        width: 100px;
        height: 160px;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-around;
    }
 .dashboard .entranceItem:hover{
     width: 100px;
     height: 160px;
     background: #f9f9f9;
     display: flex;
     flex-direction: column;
     align-items: center;
     justify-content: space-around;
 }
    .dashboard .policyStatisticsCard{
        display: flex;
        flex-direction: column;
        padding: 0;
        margin-top: 30px;
    }
    .dashboard .policyStatistics{
        min-width:160px;
        display: flex;
        flex-direction: column;
        padding: 0 30px;
        border-right:1px solid #414141
    }
    .dashboard .policyStatisticsItem{
        margin-top: 50px;
        display: flex;
        flex-direction: column;
        font-size: 12px;
    }
 .triangleSpanRed{
     color: red;
     display: flex;
 }
 .triangleSpanGreen{
     color: green;
     display: flex;
 }
 .triangleSpanRed .triangle{
     width: 0;height: 0;
     margin: 5px 7px 0 0 ;
     border: 5px solid red;
     border-top-color: red;
     border-bottom: none;
     border-left-color: transparent;
     border-right-color: transparent;
 }
 .triangleSpanGreen .triangle{
     width: 0;height: 0;
     margin: 5px 7px 0 0 ;
     border: 5px solid green;
     border-bottom-color: green;
     border-top: none;
     border-left-color: transparent;
     border-right-color: transparent;
 }

</style>
