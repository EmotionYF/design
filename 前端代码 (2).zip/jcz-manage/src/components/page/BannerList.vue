<template>
    <div class="BannerList">
        <h2 class="titleText">轮播图管理</h2>
        <el-table
                :data="bannerList"
                style="width: 100%"
                ref="multipleTable">
            <el-table-column
                    label="标题"
                    prop="bannerName"
            >
            </el-table-column>
            <el-table-column
                    label="轮播图片"
                    prop="realName"
            >
                <template slot-scope="scope">
                    <img :src="scope.row.bannerImageUrl" width="100px" height="100px"/>
                </template>
            </el-table-column>
            <el-table-column
                    label="链接"
                    prop="bannerJumpUrl"
            >
            </el-table-column>
            <el-table-column
                    label="排序"
                    prop="location"
            >
            </el-table-column>
            <el-table-column
                    label="状态"
                    prop="bannerStatus"
            >
                <template slot-scope="scope">
                    <span v-if="scope.row.bannerStatus==0">显示</span>
                    <span v-if="scope.row.bannerStatus==1">不显示</span>
                </template>
            </el-table-column>
            <el-table-column  label="操作">
                <template slot-scope="scope">
                    <el-button
                            size="mini"
                            type="primary"
                            @click="editBanner(scope.row)"
                    >编辑</el-button>
                    <el-button
                            size="mini"
                            type="danger"
                            @click="daleteBanner(scope.row.id)"
                    >删除</el-button>
                </template>
            </el-table-column>
        </el-table>
        <template>
            <div class="block pagination">
                <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page.sync="curPage"
                        :page-sizes="[10,20,50]"
                        :page-size.sync="pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="itemCount">
                </el-pagination>
            </div>
        </template>
        <el-dialog :title="dialogTitle" :visible.sync="editVisible" width="500px"  :close-on-click-modal="false">
            <el-form ref="editForm" :model="form" label-width="120px">
                <el-form-item label="标题" prop="name">
                    <el-input type="text" v-model="form.bannerName" maxlenght="10"></el-input>
                </el-form-item>
                <el-form-item label="轮播图片" prop="logo">
                    <el-upload
                            class="avatar-uploader"
                            :action="this.$api.uploadImage"
                            :headers=headers
                            :data="{imgType:1}"
                            name="file"
                            :show-file-list="false"
                            :on-success="handleBannerImageSuccess"
                    >
                        <img v-if="form.bannerImageUrl" :src="form.bannerImageUrl" class="avatar">
                        <i v-else class="el-icon-plus
                        avatar-uploader-icon"></i>
                    </el-upload>
                </el-form-item>
                <el-form-item label="跳转链接" prop="path">
                    <el-input type="text" v-model="form.bannerJumpUrl"></el-input>
                </el-form-item>
                <el-form-item label="是否显示" prop="shareMusic">
                    <el-switch
                            v-model="form.bannerStatus"
                            active-color="#13ce66"
                            inactive-color="#ccc">
                    </el-switch>
                </el-form-item>
                <el-form-item label="排序" prop="name">
                    <el-input type="text" v-model="form.location" maxlenght="10"></el-input>
                </el-form-item>
            </el-form>


            <span slot="footer" class="dialog-footer">
                <el-button type="info" @click="editVisible = false">取 消</el-button>
                <el-button type="primary" @click="submit()">确 定</el-button>
            </span>
        </el-dialog>
        <el-row style="margin-top: 30px">
            <el-button @click="addBanner">新增轮播图</el-button>
        </el-row>
    </div>
</template>

<script>
    import {getLocalStg,removeLocalStg} from '../common/common';
    export default {
        name: 'BannerList',
        mounted(){
            this.getBannerList()
        },
        data(){
            return{
                editVisible:false,
                bannerList:[],
                form:{
                    id:"",
                    bannerName:"",
                    bannerImageUrl:"",
                    bannerJumpUrl:"",
                    bannerStatus:false,
                    location:"",
                },
                dialogTitle:"编辑",
                headers:{ "jcz-admin-token":getLocalStg("JCZ_ADMIN_TOKEN"),},
                itemCount:"",
                pageSize:10,
                curPage:1,
            }
        },
        methods:{
            daleteBanner(id){
                this.$http({
                    method: 'get',
                    url: this.$api.deleteBanner,
                    params:{
                        id:id
                    }
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.$message.success("删除成功")
                            this.getBannerList()
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(res.message)
                    })
            },
            addBanner(){
                this.form = {
                    id:"",
                    bannerName:"",
                    bannerImageUrl:"",
                    bannerJumpUrl:"",
                    bannerStatus:false,
                    location:"",
                }
                this.editVisible = true
                this.dialogTitle = "新增"
            },
            submit(){
                let api = ""
                let successText = ""
                console.log(this.dialogTitle,'this.dialogTitle')
                if (this.dialogTitle=="编辑"){
                    api =this.$api.updateBanner
                    successText ="修改成功"

                }else {
                    api = this.$api.addBanner
                    successText ="添加"
                }
                let tempFrom = this.form
                tempFrom.bannerStatus = tempFrom.bannerStatus?0:1
                this.$http({
                    method: 'post',
                    url: api,
                    data:tempFrom
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.$message.success(successText)
                            this.editVisible = false
                            this.getBannerList()
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(res.message)
                    })
            },
            editBanner(row){
                this.form = {
                    id:row.id,
                    bannerName:row.bannerName,
                    bannerImageUrl:row.bannerImageUrl,
                    bannerJumpUrl:row.bannerJumpUrl,
                    bannerStatus:row.bannerStatus==0?true:false,
                    location:row.bannerStatus,
                }
                this.editVisible = true
                this.dialogTitle = "编辑"
            },
            getBannerList(){
                this.$http({
                    method: 'post',
                    url: this.$api.selectBannerList,
                    headers:{},
                    data:{
                        "curPage":this.curPage,
                        "pageSize":this.pageSize
                    }
                })
                    .then((res)=> {
                        if(res.code==200){
                           this.bannerList = res.data.list
                           this.itemCount = res.data.totalCount
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                            this.$message.error(res.message)
                        })
            },
            //上传图片成功
            handleBannerImageSuccess(res){
                this.form.bannerImageUrl = res.data
            },
            handleSizeChange(val) {
                this.pageSize = val
                this.getBannerList()
            },
            handleCurrentChange(val) {
                this.curPage = val
                this.getBannerList()
            },
        }
    };
</script>

<style >
    .BannerList .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        width: 180px;
        height: 180px;
    }

    .BannerList .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }

    .BannerList .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px !important;
        text-align: center;
    }
</style>
<style scoped>
    .BannerList .titleText{
        padding: 20px;
        margin-bottom: 80px;
        border-bottom: 1px solid #CCCCCC;
    }
    .BannerList .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>