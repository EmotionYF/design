<template>
    <div class="ReleaseProducts">
        <h2 >发布商品</h2>
        <p class="titleText">输入商品基本信息</p>
        <el-form :inline="true" :rules="rules" :model="product"  class="demo-form-inline" label-width="100px" label-position="left" ref="editForm">
            <el-row>
                <el-form-item label="商品标题" prop="productName" >
                    <el-input
                            clearable
                            size="mini"
                            placeholder="请输入商品标题"
                            v-model="product.productName">
                    </el-input>
                </el-form-item>
                <el-form-item label="商品单价" prop="price">
                    <div style="display: flex" >
                    <el-input
                            clearable
                            size="mini"
                            placeholder="请输入商品单价"
                            v-model="product.price">
                    </el-input><span style="margin-left: 8px">元</span></div>
                </el-form-item>
            </el-row>
            <el-row>
                <el-form-item label="商品品牌" prop="brand" >
                    <el-input
                            clearable
                            size="mini"
                            placeholder="请输入商品品牌"
                            v-model="product.brand">
                    </el-input>
                </el-form-item>
                <el-form-item label="商品分类" prop="productType">
                    <el-input
                            clearable
                            size="mini"
                            placeholder="请输入商品分类"
                            v-model="product.productType">
                    </el-input>
                </el-form-item>
            </el-row>
            <el-row>
                <el-form-item label="产品封面图" prop="imgs">
                    <el-upload
                            class="upload-demo"
                            :action="this.$api.uploadImage"
                            :headers=headers
                            name="file"
                            v-model="product.imgs"
                            :file-list="product.imgs"
                            :data="{imgType:1}"
                            :on-remove="handlePosterRemove"
                            :on-success="handleImageSuccess"
                            :before-upload="beforeAvatarUpload"
                            :limit="4"
                            list-type="picture-card">
                        <i class="el-icon-plus"></i>
                    </el-upload>
                </el-form-item>
            </el-row>
            <el-row>
            <el-form-item label="商品描述" prop="describe">
                <el-input
                        style="width: 530px"
                        type="textarea"
                        :autosize="{ minRows: 2, maxRows: 4}"
                        placeholder="请输入内容"
                        v-model="product.describe">
                </el-input>
            </el-form-item>
            </el-row>

        </el-form>
        <el-button round @click="submitProduct">发  布</el-button>
        <el-button round @click="cancel">取  消</el-button>
    </div>
</template>

<script>
    import {getLocalStg,removeLocalStg} from '../common/common';
    export default {
        name: 'ReleaseProducts',
        data(){
            return{
                textarea2:"",
                rules:{
                    productName: [
                        {whitespace: true, message: '禁止输入空格', trigger: 'blur'},
                        {required: true, message: '请输入商品标题', trigger: 'blur'},
                    ],
                    brand: [
                        {whitespace: true, message: '禁止输入空格', trigger: 'blur'},
                        {required: true, message: '请输入属性名', trigger: 'blur'},
                    ],
                    productType: [
                        {whitespace: true, message: '禁止输入空格', trigger: 'blur'},
                        {required: true, message: '请输入商品类别', trigger: 'blur'},
                    ],
                    describe: [
                        {required: true, message: '请输入商品描述', trigger: 'blur'},
                    ],
                    price: [
                        {whitespace: true, message: '禁止输入空格', trigger: 'blur'},
                        {required: true, message: '请输入商品单价', trigger: 'blur'},
                    ],
                    imgs: [
                        {required: true, message: '请上传图片', trigger: 'blur'},
                    ],
                },
                headers:{ "jcz-admin-token":getLocalStg("JCZ_ADMIN_TOKEN"),},
                product:{
                    productName:"",//商品名称
                    brand:"",//商品品牌
                    price:"",//商品单价
                    productType:"",//类型
                    describe:"",//描述
                    imgs:[],//图片路径
                },
            }
        },
        mounted(){
            this.product ={
                productName:"",//商品名称
                    brand:"",//商品品牌
                    price:"",//商品单价
                    productType:"",//类型
                    describe:"",//描述
                    imgs:[],//图片路径
            },
            console.log(this.$route.query.id,"this.$route.query.id")
            if (this.$route.query.id){
                this.checkDetails(this.$route.query.id)
            }

        },
        activated(){
            this.product ={
                productName:"",//商品名称
                brand:"",//商品品牌
                price:"",//商品单价
                productType:"",//类型
                describe:"",//描述
                imgs:[],//图片路径
            },
            console.log(this.$route.query.id,"this.$route.query.id")
            if (this.$route.query.id){
                this.checkDetails(this.$route.query.id)
            }
        },
        methods:{
            //获取详情信息
            checkDetails(id){
                this.$http({
                    method: 'get',
                    url: this.$api.getProductById,
                    headers:{},
                    params:{
                        id:id
                    }
                })
                    .then((res)=> {
                        if(res.code==200){
                            console.log(res.data)
                            this.product =res.data
                            console.log(this.product.imgs,"product.imgs")
                            this.product.imgs = this.product.imgs.map(item => {
                                return {url: item}
                            })
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(res.message)
                    })
            },
            cancel(){
                this.$router.replace('/ProductListPage');
            },
            submitProduct(){
                let submitStatus = true;
                //提交表单校验
                this.$refs["editForm"].validate((valid) => {
                    if (valid) {
                        submitStatus = true;
                    } else {
                        submitStatus = false;
                    }
                });
                //校验失败
                if (!submitStatus) {
                    this.$message.error("请检查表单必填项");
                    return;
                }
                let api = ""
                if(this.$route.query.id){
                    api = this.$api.updateProduct
                }else {
                    api = this.$api.releaseProduct
                }
                this.$http({
                    method: 'post',
                    url: api,
                    headers:{},
                    data:this.product
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.$message.success("发布成功");
                            this.$router.replace('/ProductListPage');
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(res.message)
                    })

            },
            beforeAvatarUpload(file) {
                let reg2 = /^(\s|\S)+(jpg|png|JPG|PNG|jpeg)+$/;
                let isImg = true;

                const isLt2M = file.size / 1024 / 1024 <2;
                console.log(file.type)
                if (!reg2.test(file.type)) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                    isImg = false;
                }
                if (!isLt2M) {
                    this.$message.error('上传头像图片大小不能超过 2MB!');
                }
                return isImg && isLt2M;
            },
            handleImageSuccess(res, file, fileList){
                console.log(res,"res")
                this.product.imgs.push(res.data)
            },
            //删除图片
            handlePosterRemove(file, fileList) {
                console.log(file,'file')
                console.log(this.product.imgs,'this.product.imgs')
                this.product.imgs = this.product.imgs.filter(item => {
                    return item.index != file.index
                })
            },
        },
    };
</script>
<style>
    .ReleaseProducts .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        width: 180px;
        height: 180px;
    }
    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }

    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px !important;
        text-align: center;
    }
</style>
<style scoped>
    .ReleaseProducts{
        margin: 20px 40px;
    }
    .ReleaseProducts .titleText{
        margin: 30px 0 10px;
    }
    .ReleaseProducts .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }

</style>