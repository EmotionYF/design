<template>
    <div class="updateMobile">
        <common-head :headerTitle="headerTitle"></common-head>
        <div v-if="step==0" class="step0Warp">
            <div class="hint">
                输入您的身份证号
            </div>
            <div class="inputItem">
                <img src="../../img/user/idCardIcon.png">
                <input type="text" v-model.trim="idCard" maxlength="18" placeholder="请输入您的身份证号">
            </div>
            <div class="btnNext" @click="checkIdCard()">下一步</div>
        </div>
        <div v-if="step==1" class="step1Warp">
            <div class="hint">
                请输入您要绑定的手机号
            </div>
            <div class="inputItem">
                <img src="../../img/user/phoneIcon.png">
                <input type="tel" v-model.trim="mobile" maxlength="11" placeholder="请输入手机号">
            </div>
            <div class="btnNext" @click="getAuthCode()">获取验证码</div>
        </div>
        <div v-if="step==2" class="step2Warp">
            <div class="title">输入验证码</div>
            <div class="content">验证码已发送至+86 {{mobile}}</div>
        <label for="code">
                <ul class="security-code-container">
                    <li class="field-wrap" v-for="(item, index) in authCodeLength" :key="index">
                        <div v-if="authCode[item-1]">{{authCode[item-1]}}</div>
                        <div class="headerBox" v-if="authCode.length==index&&isFocus">|</div>


                    </li>
                </ul>
            </label>
            <input ref="input" class="input-code" @keyup="handleInput" v-model.trim="authCode"
                   id="code" name="code" type="tel" :maxlength="authCodeLength" @focus="myFocus" @blur="myBlur"
                   autocorrect="off" autocomplete="off" autocapitalize="off">
            <div class="sendWarp">
                <span :class="isSend?'unSend':'send'" @click="sendAuthCode">收不到验证码，点此重新获得</span>
                <span class="send" style="margin-left: .1rem" v-if="isSend">{{time}}s</span>
            </div>
        </div>
        <div v-if="step==3" class="setp3Warp">
                <div class="bindImg"><img src="../../img/user/succeedBind.png"></div>
                <div class="bindText">绑定成功！</div>
                <div class="bindBtn" @click="goLastPage()">返回</div>
        </div>
        <FooterImg></FooterImg>
    </div>
</template>

<script>
    import CommonHead from "../common/CommonHead";
    import FooterImg from "../common/FooterImg"
    import {checkIdCard, checkMobile} from "../../utils/common"

    export default {
        name: "UpdateMobile",
        components: {
            CommonHead,
            FooterImg
        },
        computed: {},
        created() {
        },
        mounted() {
            console.log(this.$route.query.mobile)
           if(this.$route.query.mobile){
               console.log(1123);
               this.headerTitle="修改手机号";
               //是否显示身份证号确认
               this.isUpdate=true;
           }
           else{
               console.log(4);
               this.step++;
           }
        },
        watch: {},
        data() {
            return {
                idCard:"",
                mobile: "",
                headerTitle: "绑定手机号",
                authCodeLength: 4,
                step: 0,
                authCode: '',
                isFocus: false,
                isSend: false,
                time:0,
                isUpdate:false
            }
        },
        beforeRouteLeave(to, from, next) {
            if (this.step==2||this.step==1&&this.isUpdate) {
                this.authCode="";
                this.step--;
                next(false)
            } else {
                next()
            }
        },
        methods: {
            myBlur() {
                this.isFocus = false;
            },
            myFocus() {
                this.isFocus = true;
            },
            hideKeyboard() {
                // 输入完成隐藏键盘
                document.activeElement.blur() // ios隐藏键盘
                this.$refs.input.blur() // android隐藏键盘
                this.checkAuthCode();
            },
            handleInput() {
                this.$refs.input.value = this.authCode;
                if (this.authCode.length >= this.authCodeLength) {
                    this.hideKeyboard()
                }
                // this.handleSubmit()
            },
            checkIdCard(){
                if (!checkIdCard(this.idCard)) {
                    this.$toast("请正确输入身份证号");
                    return;
                }
                this.$http({
                    method: "POST",
                    url: this.$api.checkIdCardInPerson,
                    data: {
                        "idCard":this.idCard
                    }
                })
                    .then(res => {
                        console.log(res);
                        if (res.code == 200) {
                            this.step++;
                        } else {
                            this.$toast(res.message);
                        }
                    })
                    .catch(rtn => {

                    });
            },
            getAuthCode() {
                if (!checkMobile(this.mobile)) {
                    this.$toast("请正确输入手机号码");
                    return;
                }
                if(this.$route.query.mobile==this.mobile){
                    this.$toast("与当前手机一致，无需更改！");
                    return;
                }
              // this.authCode="";
              // this.step++;
              // if (!this.isSend) {
              //   this.sendAuthCode();
              // }
              this.$http({
                method: "GET",
                url: this.$api.updateMobile,
                params: {
                  "phone":this.mobile + ''
                }
              })
                .then(res => {
                  console.log(res);
                  if (res.code == 200) {
                    this.authCode="";
                    this.step++;
                    if (!this.isSend) {
                      this.sendAuthCode();
                    }
                  } else {
                    this.$toast("该手机已被绑定");
                  }
                })
                .catch(rtn => {
                });

            },
            sendAuthCode() {
                if(this.isSend){
                    return;
                }
                this.$http({
                    method: "POST",
                    url: this.$api.sendSMS,
                    data: {
                        "mobile":this.mobile
                    }
                })
                    .then(res => {
                        console.log(res);
                        if (res.code == 200) {
                            this.isSend=true;
                            this.updateCountDown();
                        } else {
                            this.$toast(res.message);
                        }
                    })
                    .catch(rtn => {

                    });
            },
            checkAuthCode(){
                if(this.authCode.length!=4){
                    this.$toast("请正确输入验证码");
                    return;
                }
                this.$http({
                    method: "POST",
                    url: this.$api.bondMobile,
                    data: {
                        mobile:this.mobile,
                        code:this.authCode
                    }
                })
                    .then(res => {
                        console.log(res);
                        if (res.code == 200) {
                            this.step++;
                        } else {
                            this.authCode="";
                            this.$toast(res.message);
                        }
                    })
                    .catch(rtn => {

                    });
            },
            updateCountDown() {
                 this.time = 60;
                let timer = setInterval(() => {
                    this.time--;
                    // this.countDown = time + "秒";
                    if ( this.time == 0) {
                        this.isSend = false;
                        clearInterval(timer)
                    }
                }, 1000)
            },
            goLastPage(){
                this.$router.go(-1);
            }
        },
    }
</script>

<style lang="scss" scoped type="text/scss">
    .updateMobile {
        height: 100%;
        overflow: hidden;
        .step0Warp {
            .inputItem {
                margin-top: .3rem;
                margin-left: .53rem;
                display: flex;
                align-items: center;
                border-bottom: 1px solid #EDEDED;
                padding-bottom: .09rem;
                width: 2.8rem;

                img {
                    width: .2rem;
                    height: .2rem;
                    margin-right: .2rem;
                }

                input {
                    flex: 1;
                    border: 0;
                    letter-spacing: .01rem;
                    height: 0.22rem;
                    font-size: 0.16rem;
                    font-family: PingFang-SC-Medium, PingFang-SC;
                    font-weight: 500;
                    color: #414141;
                    line-height: 0.22rem;
                }

            }

            .hint {
                margin: .4rem 0 0 .55rem;
                height: 0.22rem;
                line-height: 0.22rem;
                font-size: 0.16rem;
                font-family: PingFang-SC-Medium, PingFang-SC;
                font-weight: 500;
                color: #414141;

            }

            .btnNext {
                margin: 1.2rem auto 0;
                width: 3rem;
                height: .44rem;
                line-height: .44rem;
                background: $defaultColor;
                border-radius: 0.1rem;
                font-size: 0.16rem;
                font-family: PingFang-SC-Medium, PingFang-SC;
                font-weight: 500;
                color: rgba(255, 255, 255, 1);
                text-align: center;
            }
        }
        .step1Warp {
            .inputItem {
                margin-top: .3rem;
                margin-left: .53rem;
                display: flex;
                align-items: center;
                border-bottom: 1px solid #EDEDED;
                padding-bottom: .09rem;
                width: 2.8rem;

                img {
                    width: .2rem;
                    height: .2rem;
                    margin-right: .2rem;
                }

                input {
                    flex: 1;
                    border: 0;
                    letter-spacing: .01rem;
                    height: 0.22rem;
                    font-size: 0.16rem;
                    font-family: PingFang-SC-Medium, PingFang-SC;
                    font-weight: 500;
                    color: #414141;
                    line-height: 0.22rem;
                }

            }

            .hint {
                margin: .4rem 0 0 .55rem;
                height: 0.22rem;
                line-height: 0.22rem;
                font-size: 0.16rem;
                font-family: PingFang-SC-Medium, PingFang-SC;
                font-weight: 500;
                color: #414141;

            }

            .btnNext {
                margin: 1.2rem auto 0;
                width: 3rem;
                height: .44rem;
                line-height: .44rem;
                background: $defaultColor;
                border-radius: 0.1rem;
                font-size: 0.16rem;
                font-family: PingFang-SC-Medium, PingFang-SC;
                font-weight: 500;
                color: rgba(255, 255, 255, 1);
                text-align: center;
            }
        }

        .step2Warp {
            .title {
                margin: .37rem 0 0 .55rem;
                height: 0.28rem;
                line-height: 0.28rem;
                font-size: 0.2rem;
                font-family: PingFang-SC-Medium, PingFang-SC;
                font-weight: 500;
                color: #414141;

            }

            .content {
                margin: .04rem 0 0 .55rem;
                height: 0.2rem;
                line-height: 0.2rem;
                font-size: 0.14rem;
                font-family: PingFang-SC-Medium, PingFang-SC;
                font-weight: 500;
                color: rgba(129, 129, 129, 1);

            }

            .security-code-container {
                margin: .22rem .54rem 0;
                padding: 0;
                display: flex;
                justify-content: space-between;

                .field-wrap {
                    list-style: none;
                    display: block;
                    width: .5rem;
                    height: .42rem;
                    line-height: .42rem;
                    text-align: center;
                    font-size: .25rem;
                    background-color: #fff;
                    color: $defaultColor;
                    border-bottom: 1px solid #EDEDED;

                    .char-field {
                        font-style: normal;
                    }
                }
            }

            .input-code {
                position: absolute;
                left: -99rem;
                top: -99rem;
                opacity: 0;
                overflow: visible;
                z-index: -1;
            }

            .headerBox {
                animation: fade 1s infinite;
            }

            @keyframes fade {
                from {
                    opacity: 1.0;
                }
                50% {
                    opacity: 0.0;
                }
                to {
                    opacity: 1.0;
                }
            }

            .sendWarp {
                margin: .15rem 0 0 .55rem;

                .send {
                    height: 0.17rem;
                    line-height: 0.17rem;
                    font-size: 0.12rem;
                    font-family: PingFang-SC-Medium, PingFang-SC;
                    font-weight: 500;
                    color: rgba(216, 24, 35, 1);

                }

                .unSend {
                    height: 0.17rem;
                    line-height: 0.17rem;
                    font-size: 0.12rem;
                    font-family: PingFang-SC-Medium, PingFang-SC;
                    font-weight: 500;
                    color: rgba(129, 129, 129, 1);

                }
            }
        }

        .setp3Warp {
            .bindImg{
                margin: .4rem auto 0;
                text-align: center;
                img{
                    width: 1rem;
                    height: .89rem;
                }
            }
            .bindText{
                margin-top: .25rem;
                text-align: center;
                height:0.25rem;
                font-size:0.18rem;
                font-family:PingFangSC-Regular,PingFang SC;
                font-weight:400;
                color:rgba(65,65,65,1);
                line-height:0.25rem;
            }
            .bindBtn{
                margin: .67rem auto 0;
                width:3rem;
                height:.44rem;
                line-height: .44rem;
                background:$defaultColor;
                border-radius:0.1rem;
                font-size:0.16rem;
                font-family:PingFang-SC-Medium,PingFang-SC;
                font-weight:500;
                color:rgba(255,255,255,1);
                text-align: center;
            }
        }

    }
</style>
