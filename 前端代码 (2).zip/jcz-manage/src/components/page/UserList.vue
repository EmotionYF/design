<template>
    <div class="UserList">
    <h2 class="titleText">用户管理 </h2>
        <el-form :inline="true" style="text-align: left" label-width="80px" label-position="left">
            <el-form-item label="用户昵称">
                <el-input clearable placeholder="请输入商品名称" v-model="tempNickName"></el-input>
            </el-form-item>
            <el-form-item label="手机号码">
                <el-input clearable placeholder="请选择订单编号" v-model="tempPhoneNum"></el-input>
            </el-form-item>
            <el-form-item>
                <el-button style="float: right;margin-left: 5px" type="primary" @click="searchOrderList" >查询</el-button>
            </el-form-item>
        </el-form>
    <el-table
            :data="userList"
            style="width: 100%"
            ref="multipleTable">
        <el-table-column
                label="用户昵称"
                prop="userName"
        >
        </el-table-column>
        <el-table-column
                label="手机号"
                prop="phone"
        >
        </el-table-column>
        <el-table-column
                label="注册时间"
                prop="createTime"
                :formatter="formatDate"
        >
        </el-table-column>
    </el-table>
        <template>
            <div class="block pagination">
                <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page.sync="curPage"
                        :page-sizes="[10,20,50]"
                        :page-size.sync="pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="itemCount">
                </el-pagination>
            </div>
        </template>

    </div>
</template>

<script>
    import {dateForment} from '../common/common';
    export default {
        name: 'UserList',
        components:{
            dateForment
        },
        data(){
            return{
            userList:[],
                curPage:1,
                pageSize:10,
                itemCount:0,
                tempPhoneNum:"",
                tempNickName:"",
                userName:"",
                phone:"",
            }
        },
        mounted(){
            this.getUserList()
        },
        methods:{
            searchOrderList(){
                this.userName = this.tempNickName
                this.phone = this.tempPhoneNum
                this.curPage = 1
                this.getUserList()
            },
            //时间戳换成日期
            formatDate(row,column) {
                return(dateForment(row.createTime,"yyyy-MM-dd HH:mm:ss"));
            },
            getUserList(){
                this.$http({
                    method: 'post',
                    url: this.$api.userManage,
                    headers:{},
                    data:{
                        "curPage":this.curPage,
                        "pageSize":this.pageSize,
                        "userName":this.userName,
                        "phone":this.phone,
                    }
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.userList = res.data.list
                            this.itemCount = res.data.totalCount
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(res.message)
                    })
            },
            handleSizeChange(val) {
                this.pageSize = val
                this.getUserList()
            },
            handleCurrentChange(val) {
                this.curPage = val
                this.getUserList()
            },
        }
    };
</script>

<style scoped>
    .UserList .titleText{
        padding: 20px;
        margin-bottom: 80px;
        border-bottom: 1px solid #CCCCCC;
    }
</style>