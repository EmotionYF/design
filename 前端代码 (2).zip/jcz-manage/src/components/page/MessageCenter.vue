<template>
    <div class="messageCenter">
        <div class="myHeaderWarp">
         <div class="myheader">
                <img  @click="goLastPage" src="../../img/common/backWhite.png" class="myheader-icon-bg" >
                <span class="myheader-title">消息中心</span>
             <div class="myHeader-btn" @click="delNotice">清空消息</div>
            </div>
            <div class="myheader-bg"></div>
        </div>
        <div class="noMessageWarp" v-if="noMessage">
            <img src="../../img/message/noMessage.png">
            <div class="text">暂无消息</div>
        </div>


        <div class="messageWarp" v-else>
            <van-list
                    v-model="loading"
                    :finished="finished"
                    finished-text="暂无更多"
                    @load="getMessageList"
                    :offset=10
            >
                <div v-for="item in messageList">
                <div class="messageItem">
                    <div class="titleAndTime">
                        <div class="title">{{item.noticeTitle}}</div>
                        <div class="time">{{item.sendTime | formatSendTime}}</div>
                    </div>
                    <div class="content">
                        {{item.noticeInfo}}
                    </div>
                </div>
                <div class="line5"></div>
                </div>
            </van-list>
        </div>
    </div>

</template>

<script>
    import {List,} from 'vant';
    import  {dateForment} from "../../utils/common";
    export default {
        name: "MessageCenter",
        components: {
            [List.name]: List,
        },
        created() {
        },
        mounted() {
        },
        watch: {},
        filters:{
            formatSendTime(val){
                console.log(val);
                return dateForment(val,"yyyy-MM-dd HH:mm")
            }
        },
        data() {
            return {
                curPage:1,
                noMessage:false,
                messageList:[],
                loading:false,
                finished:false
            }
        },
        methods: {
            goLastPage(){
                this.$router.go(-1);
            },
            getMessageList(){
                this.$http({
                    method: "POST",
                    url: this.$api.noticeList,
                    data: {
                        "curPage":this.curPage,
                        "pageSize":10
                    }
                })
                    .then(res => {
                        console.log(res);
                        if (res.code == 200) {
                            this.loading=false;
                            //判断是否返回没有消息
                            if(res.data.totalCount==0){
                                this.noMessage=true;
                            }
                            this.messageList.push(...res.data.list);
                            if(this.messageList.length==res.data.totalCount){
                                this.finished=true;
                            }else{
                                this.curPage++;
                            }

                        } else {
                            this.$toast(res.message);
                        }
                    })
                    .catch(rtn => {
                    });
            },
            delNotice(){
                this.$dialog.confirm({
                    title:"提示",
                    message: '确认清空所有消息吗？',
                    confirmButtonColor:"#D81823",
                })
                    .then(() => {
                    this.$http({
                        method: "POST",
                        url: this.$api.delNotice,
                        data: {
                        }
                    })
                        .then(res => {
                            console.log(res);
                            if (res.code == 200) {
                                this.noMessage=true;
                                console.log(res.data);
                            } else {
                                this.$toast(res.message);
                            }
                        })
                        .catch(rtn => {
                        });
                })
                    .catch(() => {
                    // on cancel
                });

            }
        },
    }
</script>

<style lang="scss" scoped type="text/scss">
    .messageCenter {
        height: 100%;
        .myHeaderWarp{
            .myheader{
                font-size: 16px;
                color: #414141;
                height: .44rem;
                line-height: .44rem;
                position: fixed;
                width: 100%;
                z-index: 1;
                display: flex;
                align-items: center;
                background:linear-gradient(270deg,rgba(216,24,35,1) 0%,rgba(211,42,48,1) 100%);
            }
            .myheader-bg{
                width: 100%;
                height: .44rem;
            }
            .myheader-icon-bg{
                width: .23rem;
                height: .23rem;
                position: absolute;
                z-index: 1;
                left: .12rem;
            }
            .myheader-title{
                font-size:.16rem;
                position: absolute;
                display: block;
                text-align: center;
                width: 100%;
                font-family:PingFangSC-Regular,PingFang SC;
                font-weight:400;
                color:rgba(255,255,255,1);
            }
            .myHeader-btn{
                font-size:.12rem;
                position: absolute;
                display: block;
                right:.17rem;
                z-index: 1;
                font-family:PingFangSC-Regular,PingFang SC;
                font-weight:400;
                color:rgba(255,255,255,1);


            }
        }
        .noMessageWarp{
            text-align: center;
            img{
                margin-top: .5rem;
                width: 2.8rem;
                height: 2.08rem;
            }
            .text{
                margin-top: .2rem;
                font-size:0.18rem;
                font-family:PingFang-SC-Medium,PingFang-SC;
                text-align: center;
                font-weight:500;
                color:rgba(65,65,65,1);
            }
        }
        .messageWarp{
            .messageItem{
                background: #fff;
                padding: .15rem .16rem;
                .titleAndTime{
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    .title{
                        height:0.22rem;
                        line-height:0.22rem;
                        font-size:0.16rem;
                        font-family:PingFangSC-Regular,PingFang SC;
                        font-weight:400;
                        color:rgba(65,65,65,1);

                    }
                    .time{
                        height:0.2rem;
                        line-height:0.2rem;
                        font-size:0.14rem;
                        font-family:PingFangSC-Regular,PingFang SC;
                        font-weight:400;
                        color:rgba(97,97,97,1);

                    }
                }
                .content{
                    margin-top: .14rem;
                    font-size:0.12rem;
                    font-family:PingFangSC-Regular,PingFang SC;
                    font-weight:400;
                    color:rgba(97,97,97,1);
                    line-height:0.17rem;
                }
            }
            .line5{
                width: 100%;
                height: 0.05rem;
                background: #F9F9F9;
            }
        }
    }
</style>
