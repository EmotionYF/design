<template>
    <div class="OrderList">
        <h2 class="titleText">订单管理</h2>
        <div  style="margin: 20px">
            <el-form :inline="true" style="text-align: left" label-width="80px" label-position="left">
                <el-form-item label="商品名称">
                    <el-input clearable placeholder="请输入商品名称" v-model="tempProductName"></el-input>
                </el-form-item>
                <el-form-item label="下单时间">
                    <el-date-picker
                            v-model="timeDifferent"
                            type="daterange"
                            align="right"
                            unlink-panels
                            size="mini"
                            value-format="yyyy-MM-dd"
                            range-separator="至"
                            start-placeholder="开始日期"
                            end-placeholder="结束日期"
                            @change="chooseDifferent">
                    </el-date-picker>
                </el-form-item>
                <el-form-item label="订单编号">
                    <el-input clearable placeholder="请选择订单编号" v-model="tempOrderNumber"></el-input>
                </el-form-item>
                <el-form-item label="订单状态">
                    <el-select style="width: 100%" size="mini" value-key="id" v-model="tempStatus"
                               clearable placeholder="请选择订单状态">
                        <el-option
                                v-for="item in orderStatusList"
                                :key="item.id"
                                :label="item.value"
                                :value="item.id">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                <el-button style="float: right;margin-left: 5px" type="primary" @click="searchOrderList" >查询</el-button>
                </el-form-item>
            </el-form>
        </div>
        <el-table
                :data="orderList"
                style="width: 100%"
                ref="multipleTable">
            <el-table-column
                    label="订单编号"
                    prop="orderNumber"
                    >
            </el-table-column>
            <el-table-column
                    :formatter="formatDate"
                    label="下单时间"
                    prop="createTime"
                    >
            </el-table-column>
            <el-table-column
                    label="商品"
                    prop="realName"
                    width="200"
                    >
                <template slot-scope="scope">
                    <div style="display: flex">
                        <img :src="scope.row.pictureUrl" width="100px">
                        <div style="min-width: 80px">{{scope.row.productName}}</div>
                    </div>
                </template>
            </el-table-column>
            <el-table-column
                    label="数量"
                    prop="count"
            >
            </el-table-column>
            <el-table-column
                    label="买家信息"
                    prop="realName"
            >
                <template slot-scope="scope">
                    <div>{{scope.row.userName}}</div>
                    <div>{{scope.row.phone}}</div>
                    <div>{{scope.row.adress}}</div>
                </template>
            </el-table-column>
            <el-table-column
                    label="交易状态"
                    prop="status"
            >
                <template slot-scope="scope">
                    <span v-if="scope.row.status==0">订单初始化</span>
                    <span v-if="scope.row.status==1">待支付</span>
                    <span v-if="scope.row.status==2">待发货</span>
                    <span v-if="scope.row.status==3">保留订单</span>
                </template>
            </el-table-column>
            <el-table-column
                    label="实收款"
                    prop="income"
                    >
            </el-table-column>
            <el-table-column
            >
                <template slot-scope="scope">
                    <el-button v-if ="scope.row.status==2" size="mini" @click="toSendProduct(scope.row.id)">去发货</el-button>
                </template>
            </el-table-column>
        </el-table>
        <template>
            <div class="block pagination">
                <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page.sync="curPage"
                        :page-sizes="[10,20,50]"
                        :page-size.sync="pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="itemCount">
                </el-pagination>
            </div>
        </template>
    </div>
</template>
<script>
    import {dateForment} from '../common/common';
    export default {
        name: 'OrderList',
        components:{
            dateForment
        },
        data(){
            return{
                //临时条件变量值
                tempStartTime:"",
                tempEndTime:"",
                tempProductName:"",
                tempOrderNumber:"",
                tempStatus:"",

                pageSize:10,
                curPage:1,
                itemCount:0,
                orderNumber:"",
                endTime:"",
                startTime:"",
                status:"",
                productName:"",
                orderList:[],
                timeDifferent:[],//时间选择器差值
                orderStatusList:[
                    {id:2,value:"待发货"},
                    {id:3,value:"保留订单"},
                ],
            }
        },
        mounted(){
            this.getOrderManage()
        },
        methods:{
            //时间戳换成日期
            formatDate(row,column) {
                return(dateForment(row.createTime,"yyyy-MM-dd HH:mm:ss"));
            },
            //按条件查询
            searchOrderList(){
                this.curPage = 1
                this.orderNumber = this.tempOrderNumber
                this.startTime = this.tempStartTime
                this.endTime = this.tempEndTime
                this.productName = this.tempProductName
                this.status = this.tempStatus
                this.getOrderManage()
            },
            //选择时间
            chooseDifferent(val){
                console.log(val)
                this.tempStartTime = val[0]
                this.tempEndTime = val[1]
            },
            //获取订单列表
            getOrderManage(){
                this.$http({
                    method: 'post',
                    url: this.$api.orderManage,
                    headers:{},
                    data:{
                        "curPage":this.curPage,
                        "pageSize":this.pageSize,
                        "productName":this.productName,
                        "startTime":this.startTime,
                        "endTime":this.endTime,
                        "orderNumber":this.orderNumber,
                        "status":this.status,
                    }
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.orderList = res.data.list
                            this.itemCount = res.data.totalCount
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(res.message)
                    })
            },
            //去发货
            toSendProduct(id){
                this.$http({
                    method: 'get',
                    url: this.$api.sendProduct,
                    headers:{},
                    params:{
                        orderId:id
                    }
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.getOrderManage()
                            this.$message.success("操作成功");
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(res.message)
                    })
            },
            handleSizeChange(val) {
                this.pageSize = val
                this.getOrderManage()
            },
            handleCurrentChange(val) {
                this.curPage = val
                this.getOrderManage()
            },
        }
    };
</script>

<style scoped>
    .OrderList .titleText{
        padding: 20px;
        margin-bottom: 80px;
        border-bottom: 1px solid #CCCCCC;
    }
</style>