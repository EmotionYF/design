<template>
    <div class="productListPage">
        <el-row style="margin: 20px auto">
            <el-button-group>
            <el-button @click="checkProductByStatus(2)" :type="this.productStatus==null?'primary':''">全部</el-button>
            <el-button @click="checkProductByStatus(0)" :type="this.productStatus==0?'primary':''">出售中</el-button>
            <el-button @click="checkProductByStatus(1)" :type="this.productStatus==1?'primary':''">未上架</el-button>
            </el-button-group>
        </el-row>
        <el-card shadow="never" style="margin-bottom: 20px" :body-style="{padding:0 }">
            <el-form v-if="showScreen" :inline="true" style="text-align: left;margin-top: 20px" label-width="140px" >
                <el-form-item label="输入搜索：">
                    <el-input clearable placeholder="产品名称" v-model="productName"></el-input>
                </el-form-item>
                <el-button style="float: right;margin-left: 5px" type="primary" @click="checkProduct">查询</el-button>
            </el-form>

        </el-card>
        <el-card shadow="never">
            <div slot="header">
                <i class="el-icon-s-order"></i>
                <span>产品列表</span>
                <el-button style="float: right" type="primary" @click="addProduct">发布商品</el-button>
            </div>
            <el-table
                    :data="productList"
                    style="width: 100%;min-width:650px"
                    max-height="400"
                    stripe border
                    ref="multipleTable"
            >
                <el-table-column
                        type="selection"
                >
                </el-table-column>
                <el-table-column
                        label="id"
                        prop="id"
                >
                </el-table-column>
                <el-table-column
                        label="商品名称"
                        prop="productName"
                >
                </el-table-column>
                <el-table-column
                        label="价格"
                        prop="price"
                        width="120"
                >
                </el-table-column>
                <el-table-column
                        label="总销量"
                        prop="sales"
                >
                </el-table-column>
                <el-table-column label="操作" width="260" fixed="right">
                    <template class="item-btn" slot-scope="scope">
                        <el-button size="mini" type="primary" @click="chackDetails(scope.row.id)">编辑</el-button>
                        <el-button v-if="scope.row.upperShelfStatus==0" size="mini" type="danger"  @click="underCarriage(scope.row,0)">下架</el-button>
                        <el-button v-else size="mini" type="primary"  @click="underCarriage(scope.row,1)">上架</el-button>
                    </template>
                </el-table-column>
            </el-table>
        </el-card>
        <template>
            <div class="block pagination">
                <el-pagination
                        @size-change="handleSizeChange"
                        @current-change="handleCurrentChange"
                        :current-page.sync="curPage"
                        :page-sizes="[10,20,50]"
                        :page-size.sync="pageSize"
                        layout="total, sizes, prev, pager, next, jumper"
                        :total="itemCount">
                </el-pagination>
            </div>
        </template>
    </div>
</template>

<script>
    export default {
        name: 'productListPage',
        data(){
            return{
                showScreen:true,//是否显示筛选栏
                typeList:[],//类别列表
                productList:[],//产品列表
                productListInfo:"",//产品列表信息

                tempType:null,//临时类别选项
                showaddProduct:false,//是否显示添加产品列表



                productStatus:null,//产品状态
                productName:"",//搜索关键字
                orderByClause:"",//排序方式,
                pageSize:10,//每页条数
                curPage:1,//页数
                itemCount:0,//总条数

                pickerOptions0: {
                    disabledDate(time) {
                        return time.getTime() < Date.now() - 8.64e7;
                    }
                },//时间选择器的范围限制
                form:{},

                detailTitleName:"",

            }
        },
        methods:{
            //选择时间
            changeData(e){
                console.log(e)
                this.$nextTick(() => {
                    this.$set(this.form, "shelvesTime", e[0]);
                    this.$set(this.form, "unshelvesTime", e[1]);
                });
            },
            //按照状态查询
            checkProductByStatus(status){
                this.productStatus = status!=2?status:null
                this.curPage = 1
                this.getProductList()
            },
            //按照关键词查询
            checkProduct(){
                this.curPage = 1
                this.getProductList()
            },
            //修改每页条数
            handleSizeChange(val){
                this.pageSize = val;
                this.getProductList();
            },
            //修改页数
            handleCurrentChange(val){
                this.curPage = val;
                this.getProductList();
                },
            //获取产品列表
            getProductList(){
                this.$http({
                    method: 'post',
                    url: this.$api.adminProductList,
                    headers:{},
                    data:{
                        "upperShelfStatus":this.productStatus,
                        "productName":this.productName,
                        "curPage":this.curPage,
                        "pageSize":this.pageSize
                    }
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.productListInfo = res.data
                            this.itemCount = res.data.totalCount
                            this.productList = res.data.list
                            console.log(this.productList,"this.productList")
                            for (let i = 0; i <this.productList.length ; i++) {
                                console.log(1)
                                this.productList[i].recommendFlag = this.productList[i].recommendFlag==1?true:false
                                this.productList[i].newProductFlag =this.productList[i].newProductFlag==1?true:false
                                this.productList[i].shelvesFlag = this.productList[i].shelvesFlag==1?true:false
                            }
                            console.log(typeof (this.productList),"this.productList")
                            console.log(this.productList,"this.productList")
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(`网络错误`);
                    })
            },
            getProductTypeList(){
                this.$http({
                    method: 'post',
                    url: this.$api.queryProductType,
                    headers:{},
                    data:{
                    }
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.typeList = res.data
                            console.log(res.data.list)
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(`网络错误`);
                    })
            },
            //编辑
            chackDetails(id){
                this.$router.replace({"path":"/ReleaseProducts",query:{id:id}})
            },
            underCarriage(row,type){
                let api = ""
                if (type==0){
                    api =this.$api.underCarriage
                }else {
                    api =this.$api.shelves
                }
                this.$http({
                    method: 'get',
                    url: api,
                    headers:{},
                    params:{
                        id:row.id
                    }
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.$message.success("操作成功")
                            this.getProductList()
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(`网络错误`);
                    })
            },
            //删除
            deleteItem(row){
                this.$confirm('确认删除该产品？')
                    .then(_ => {
                        this.$http({
                            method: 'get',
                            url: this.$api.deleteProduct,
                            headers:{},
                            params:{
                                id:row.id
                            }
                        })
                            .then((res)=> {
                                if(res.code==200){
                                    this.$message.success("删除成功")
                                    this.checkProduct()
                                    console.log(res.data.list)
                                }else{
                                    this.$message.error(res.message);
                                }
                            })
                            .catch((error)=> {
                                this.$message.error(`网络错误`);
                            })
                    })
                    .catch(_ => {});
            },
            //点击添加产品按钮
            addProduct(){
                this.$router.replace("/ReleaseProducts")
            },
            //海报图片上传成功时间
            handlePosterSuccess(response, file){
               this.form.posterUrl = response.data
                console.log('this.form.posterUrl',this.form.posterUrl)
            },
            //产品封面图片上传成功事件
            handleFaceSuccess(response, file){
                this.form.listingPicUrl = response.data
            },
            //修改列表中三个状态开关
            changeFlag($event,row,type){
                let tempRow= JSON.parse(JSON.stringify(row))
               tempRow.recommendFlag = tempRow.recommendFlag?1:0
               tempRow.newProductFlag = tempRow.newProductFlag?1:0
               tempRow.shelvesFlag = tempRow.shelvesFlag?1:0
                this.$http({
                    method: 'post',
                    url: this.$api.productEdit,
                    headers:{},
                    data:tempRow
                })
                    .then((res)=> {
                        if(res.code==200){
                            this.checkProduct()
                            this.$message.success('修改成功')
                        }else{
                            this.$message.error(res.message);
                        }
                    })
                    .catch((error)=> {
                        this.$message.error(`网络错误`);
                    })
            },
            //一位小数校验
            proving(e) {
                // this.form.saleHeadPrice 是input的值　　
                // 先把非数字的都替换掉，除了数字和.
                this.form.saleHeadPrice = this.form.saleHeadPrice.replace(/[^\d.]/g, '');
                // 必须保证第一个为数字而不是.
                this.form.saleHeadPrice = this.form.saleHeadPrice.replace(/^\./g, '');
                // 保证只有出现一个.而没有多个.
                this.form.saleHeadPrice = this.form.saleHeadPrice.replace(/\.{2,}/g, '');
                // 保证.只出现一次，而不能出现两次以上
                this.form.saleHeadPrice = this.form.saleHeadPrice.replace('.', '$#$').replace(/\./g, '').replace('$#$', '.');
                let index = -1
                for (let i in this.form.saleHeadPrice) {
                    if (this.form.saleHeadPrice[i] === '.') {
                        index = i
                    }
                    if (index !== -1) {
                        if (i - index > 1) {
                            this.form.saleHeadPrice = this.form.saleHeadPrice.substring(0, this.form.saleHeadPrice.length - 1)
                        }
                    }
                }
            },
        },
        mounted(){
            //this.getProductTypeList()
            this.getProductList()
        },
    };
</script>

<style scoped >


</style>
<style >
    .avatar-uploader .el-upload {
        border: 1px dashed #d9d9d9;
        border-radius: 6px;
        cursor: pointer;
        position: relative;
        overflow: hidden;
        width: 180px;
        height: 180px;
    }

    .avatar-uploader .el-upload:hover {
        border-color: #409EFF;
    }

    .avatar-uploader-icon {
        font-size: 28px;
        color: #8c939d;
        width: 178px;
        height: 178px;
        line-height: 178px !important;
        text-align: center;
    }

    .avatar {
        width: 178px;
        height: 178px;
        display: block;
    }
</style>