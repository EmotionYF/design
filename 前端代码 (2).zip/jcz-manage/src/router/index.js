import Vue from 'vue';
import Router from 'vue-router';

Vue.use(Router);

export default new Router({
    routes: [
        {
            path: '/',
            redirect: '/login'
        },
        {
            path: '/',
            component: () => import(/* webpackChunkName: "home" */ '../components/common/Home.vue'),
            meta: { title: '自述文件' },
            children: [
                {
                    path: '/Dashboard',
                    component: () => import(/* webpackChunkName: "dashboard" */ '../components/page/Dashboard.vue'),
                    meta: { title: '系统首页' }
                },
                {
                    path: '/ReleaseProducts',
                    component: () => import(/* webpackChunkName: "ReleaseProducts" */ '../components/page/ReleaseProducts.vue'),
                    meta: { title: '发布产品' }
                },
                {
                    path: '/ProductListPage',
                    component: () => import(/* webpackChunkName: "dashboard" */ '../components/page/ProductListPage.vue'),
                    meta: { title: '商品列表' }
                },
                {
                    path: '/OrderList',
                    component: () => import(/* webpackChunkName: "dashboard" */ '../components/page/OrderList.vue'),
                    meta: { title: '保单查询' }
                },
                {
                    path: '/BannerList',
                    component: () => import(/* webpackChunkName: "dashboard" */ '../components/page/BannerList.vue'),
                    meta: { title: 'Banner管理' }
                },
                {
                    path: '/UserList',
                    component: () => import(/* webpackChunkName: "dashboard" */ '../components/page/UserList.vue'),
                    meta: { title: '用户管理' }
                },
            ]
        },
        {
            path: '/login',
            component: () => import(/* webpackChunkName: "login" */ '../components/page/Login.vue'),
            meta: { title: '登录' }
        },
    ]
});
