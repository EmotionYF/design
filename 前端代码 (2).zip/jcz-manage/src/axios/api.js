let env=process.env.VUE_APP_ENV;
console.log("env",env);
let api={};
if(env=="local"){
    api.baseUrl="http://localhost:11406/jczProduct/" //赵树超
    //api.baseUrl="http://producttest.doulaibao.com.cn/jczProduct/"  //测试

}
else if(env=="dat"){
    api.baseUrl="http://producttest.doulaibao.com.cn/jczProduct/"  //测试

}
//登录
api.userLogin = api.baseUrl +"userLogin/login";
api.findAccount = api.baseUrl +"userLogin/findAccount";//修改密码页面回显接口
api.updatePassword = api.baseUrl +"userLogin/updatePassword";//修改密码

//首页
api.indexInfo = api.baseUrl +"admin/index";//首页数据

//banner管理
api.selectBannerList = api.baseUrl +"banner/selectBannerList";//查询banner图
api.addBanner = api.baseUrl +"banner/addBanner";//新增banner图
api.updateBanner = api.baseUrl +"banner/updateBanner";//修改banner图
api.deleteBanner = api.baseUrl +"banner/deleteBanner";//删除banner图

//商品管理
api.releaseProduct = api.baseUrl +"admin/releaseProduct";//商品发布
api.uploadImage = api.baseUrl +"uploadFile/uploadImage";//上传图片
api.adminProductList = api.baseUrl +"admin/adminProductList";//商品列表
api.underCarriage = api.baseUrl +"product/underCarriage";//下架产品
api.shelves = api.baseUrl +"product/shelves";//上架产品
api.getProductById = api.baseUrl +"product/getProductById";//产品详情
api.updateProduct = api.baseUrl +"product/updateProduct";//修改产品


//用户
api.userManage = api.baseUrl +"admin/userManage";//用户管理


//订单
api.orderManage = api.baseUrl +"admin/orderManage";//订单列表
api.sendProduct = api.baseUrl +"admin/sendProduct";//去发货







export default api;
