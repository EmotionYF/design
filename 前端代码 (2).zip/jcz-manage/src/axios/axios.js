
import axios from 'src/axios/axios'
import {Loading,Message }from 'element-ui'
import {getLocalStg,removeLocalStg} from '../components/common/common';
import router from '../router/index';
axios.defaults.timeout = 60000;
axios.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded';
axios.defaults.headers.put['Content-Type'] = 'application/x-www-form-urlencoded';

// 请求发出拦截器
/**
 * 这个文件提交异常
 */
axios.interceptors.request.use(
    config => {
        let loading = Loading.service({
            fullscreen: true,
            text: '拼命加载中...',
        });

        if (getLocalStg("JCZ_ADMIN_TOKEN")) {
            //每个http header都加上ticket
            config.headers = {
                "jcz-admin-token":getLocalStg("JCZ_ADMIN_TOKEN"),
            }
        }else {
        }
        return config;

    },
    error => {
        Message.error({
            message: '参数错误'
        })
        let loading = Loading.service({});
        loading.close();    //关闭加载前，记得重新定义实例

        return Promise.reject(error);
    });

//请求响应拦截器

axios.interceptors.response.use(
    res => {
        console.log("res",res);
        if (res.status === 200) {
            let loading = Loading.service({});
            loading.close();    //关闭加载前，记得重新定义实例
            if(res.data.code==410){
                removeLocalStg("JDT_MANAGE_TOKEN");
                removeLocalStg("menus");
                Message.error("登录已过期，请重新登录");
                router.replace("/Login");
            }
            else if(res.data.code==401){
                removeLocalStg("JDT_MANAGE_TOKEN");
                removeLocalStg("menus");
                Message.error("暂无权限操作此项");
                router.replace("/Login");
            }
            return res.data;
        } else {
            
            let loading = Loading.service({});
            loading.close();    //关闭加载前，记得重新定义实例
        }
    },
    error => {
        //这里屏蔽掉promise的错误返回值，否则前端axios不做catch处理时控制台会出错！
        console.log("走到了错误返回值");
        console.log("error",error)
        let loading = Loading.service({});
        loading.close();    //关闭加载前，记得重新定义实例
        if (error.response.status == 500) {
            console.log('');
        } else {
            console.log('');
        }

        return Promise.reject(error);
    });

export default axios;
